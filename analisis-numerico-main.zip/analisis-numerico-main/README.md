# **Numerical Methods Calculator**
## **Members :**
### Sebastian Tapias 
### Juan Jose Moreno
### Samuel Botero

# **USER GUIDE**
#### **1 :** Download the repository and save it where you prefer.
#### **2 :** Open your terminal and when you are in the directory 'CODES', type: **python ./interface.pyw**
#### **3 :** You should see an interface such as the one below, click the method you want to calculate and follow the instructions.

![alt text](https://raw.githubusercontent.com/sboterom2/analisis-numerico/main/Final_Project/Codes/readmecalculator.PNG)
